document.addEventListener("DOMContentLoaded", (function () {
  const form = document.getElementById('login-form');
  if (!form) {
    console.error('Login form not found!');
    return;
  }
  
  console.log('Login form found, setting up event listener...');

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const username = (document.getElementById('username') || {}).value || '';
    const password = (document.getElementById('password') || {}).value || '';
    const errEl = document.getElementById('auth-error');

    if (errEl) errEl.textContent = '';

    // Debug logging
    console.log('Login attempt:', { username, password: '***' });

    // Check admin credentials first
    const isAdminUser = username.trim().toLowerCase() === 'admin';
    const isAdminPass = password === 'admin123';

    console.log('Admin check:', { isAdminUser, isAdminPass });

    if (isAdminUser && isAdminPass) {
      console.log('Admin login successful, redirecting...');
      sessionStorage.setItem('kaleo_user', JSON.stringify({ username: 'Admin', email: 'admin@sunday.com', role: 'admin' }));
      sessionStorage.setItem('kaleo_auth', 'true');
      window.location.href = '../html/admin.html';
      return;
    }

    // Check against users stored in localStorage
    try {
      const users = JSON.parse(localStorage.getItem('kaleo_users') || '[]');
      const user = users.find(u => {
        const userUsername = (u.username || '').trim().toLowerCase();
        const inputUsername = username.trim().toLowerCase();
        
        // Match by username and check password
        const usernameMatch = userUsername === inputUsername;
        const passwordMatch = u.password === password;
        
        // User must be active
        const isActive = (u.status || 'active') === 'active';
        
        return usernameMatch && passwordMatch && isActive;
      });

      if (user) {
        // Successful login
        sessionStorage.setItem('kaleo_user', JSON.stringify({ 
          username: user.username, 
          email: user.email, 
          role: user.role,
          id: user.id
        }));
        sessionStorage.setItem('kaleo_auth', 'true');
        
        // Redirect based on role
        const roleDashboardMap = {
          'admin': 'admin.html',
          'child-department': 'child-department-dashboard.html',
          'media-department': 'media-department-dashboard.html',
          'development-department-head': 'development-department-head-dashboard.html',
          'education-department': 'education-department-dashboard.html',
          'litreature-department': 'litreature-department-dashboard.html',
          'communication-department': 'communication-department-dashboard.html',
          'mezmur-department': 'mezmur-department-dashboard.html'
        };
        
        const dashboardUrl = roleDashboardMap[user.role] || 'admin.html';
        window.location.href = dashboardUrl;
        return;
      }
    } catch (error) {
      console.error('Error checking user credentials:', error);
    }

    // If we get here, credentials are invalid
    if (errEl) {
      errEl.textContent = 'Invalid credentials. Please check username and password.';
    }
  });
}));

