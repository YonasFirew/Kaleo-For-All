document.getElementById('auth-form').addEventListener('submit', function (e) {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const err = document.getElementById('auth-error');
  err.textContent = '';

  // Basic validation for empty fields
  if (!username || !password) {
    err.textContent = 'All fields are required.';
    return;
  }

  // Check if username already exists
  try {
    const users = JSON.parse(localStorage.getItem('kaleo_users') || '[]');
    const existingUser = users.find(u => (u.username || '').trim().toLowerCase() === username.toLowerCase());
    
    if (existingUser) {
      err.textContent = 'Username already exists. Please choose a different username.';
      return;
    }

    // Create new user
    const newUser = {
      id: Date.now(),
      username: username,
      password: password,
      role: 'student',
      status: 'active',
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    localStorage.setItem('kaleo_users', JSON.stringify(users));

    // Log activity
    try {
      const acts = JSON.parse(localStorage.getItem('kaleo_activity') || '[]');
      acts.unshift({
        type: 'create',
        title: 'New user registered',
        description: `${username} created an account`,
        timestamp: Date.now(),
        user: { username, role: 'student' }
      });
      localStorage.setItem('kaleo_activity', JSON.stringify(acts.slice(0,50)));
    } catch (e) { /* ignore */ }

    err.textContent = 'Account created successfully! Redirecting to login...';
    setTimeout(() => {
      window.location.href = 'login-2fa.html';
    }, 1500);
  } catch (error) {
    err.textContent = 'An error occurred. Please try again.';
    console.error('Sign up error:', error);
  }
});